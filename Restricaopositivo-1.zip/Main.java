class Main {
import java.util.Scanner

	public static void main(String[] args) {
	
	int VetPos[]=new int[10];
	int Vetor[]=new int[10];
	int Valor, Cont, x ;
  Scanner sc = new Scanner(System.in);
	System.out.println("digite 10 valores inteiros;");
			for (int i = 0; i < 10; i++) {
				
	System.out.println("-->");
  Vetor[i] = sc.nextInt();
    if(Vetor[i] > 0){
        VetPos[i] = Vetor[i];
    }else{
      
    }
		
	  }
  }
}